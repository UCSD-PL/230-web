module Haskore(module HaskoreLoader) where

import HaskoreLoader
