module Mine where 

import XMLTypes

------------------------------------------------------------------------------
-- Warm-up exercises

-- Put the solutions to these exercises here.  For each one, include at least 
-- one test case.  (These test cases don't need to be executed when the program
-- runs -- they should just be available in case someone wanted to look at them
-- from ghci, for example.)


------------------------------------------------------------------------------
-- Generic functions for transforming XML

-- Your generic functions go here...


------------------------------------------------------------------------------
-- Formatting plays

formatPlay e = PCDATA "WRITE ME!"
-- Your specific play-formatter goes here...

